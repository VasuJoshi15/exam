INSERT INTO users VALUES (1, 'Simon Li', 'lis@douglascollege.ca', 'M');
INSERT INTO users VALUES (2, 'Ivan Wong', 'wongi5@douglascollege.ca', 'M');
INSERT INTO users VALUES (3, 'Nelson Eng', 'engn@douglascollege.ca', 'M');
INSERT INTO users VALUES (4, 'Michael Ma', 'max9@douglascollege.ca', 'M');
INSERT INTO users VALUES (5, 'Rupa Manabala', 'manabalas@douglascollege.ca', 'F');
INSERT INTO users VALUES (6, 'Anupama Gupta', 'guptaa10@douglascollege.ca', 'F');